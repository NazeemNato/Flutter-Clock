# Digital Clock

This app is an example of a digital clock. That dividing the day into 100 pieces.

<img src='progclock.gif' width='350'>

<img src='night_mode_clk.png' width='350'>

<img src='light_mode_clk.png' width='350'>
